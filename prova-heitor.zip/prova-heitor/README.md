# estilizacao-react

1. Fazer o git clone: no terminal de comando digitar: <br />
  git clone -b master https://github.com/ProfKeliven/estilizacao-react.git

2. Confira se o terminal está na pasta certa! <br />
  Para navegar até a pasta correta digite no terminal de comando:<br />
  cd estilizacao-react

3. Instalar as dependencias: no terminal de comando digitar: <br />
  npm install

4. Rodar o código: no terminal de comando digitar:
  npm run dev
